import random
from datetime import datetime, timedelta
from app import create_app, db
from app.models import *
from app.services import create_seats, create_booking

AP = [("JFK", "New York", "USA"), ("LHR", "London", "UK"), ("CDG", "Paris", "France"), ("DXB", "Dubai", "UAE"),
      ("SIN", "Singapore", "Singapore"), ("SYD", "Sydney", "Australia"), ("IST", "Istanbul", "Turkey"), ("NRT", "Tokyo", "Japan")]
RT = [("JFK", "LHR", 7, 620), ("LHR", "DXB", 7, 480), ("DXB", "SIN", 7.5, 430), ("CDG", "JFK", 8, 590), ("IST", "LHR", 4, 260),
      ("SIN", "SYD", 8, 520), ("LHR", "CDG", 1.3, 120), ("IST", "DXB", 4.5, 310), ("NRT", "SIN", 7, 450), ("JFK", "NRT", 14, 980)]


def seed():
    if Airport.query.count(): return print("Already seeded.")
    random.seed(7)
    air = {c: Airport(code=c, city=ci, country=co) for c, ci, co in AP}; db.session.add_all(air.values())
    ac = Aircraft(model="Boeing 787-9 Dreamliner"); db.session.add(ac)
    for e, n, p, adm in (("admin@aurelia.demo", "Demo Admin", "AdminDemo123!", True), ("user@aurelia.demo", "Demo Traveller", "UserDemo123!", False)):
        u = User(email=e, name=n, is_admin=adm); u.set_password(p); db.session.add(u)
    base = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    n = 100
    for o, d, h, price in RT:
        for a, b in ((o, d), (d, o)):
            for day in range(1, 11):
                for hh, airline in ((8, "Aurelia Air"), (19, "Aurelia Air"), (13, "Meridian Airways")):
                    dep = base + timedelta(days=day, hours=hh, minutes=random.choice((0, 15, 30, 45)))
                    n += 1
                    f = Flight(number=f"AU{n}", airline=airline, origin=air[a], destination=air[b], depart=dep,
                               arrive=dep + timedelta(minutes=int(h * 60) + random.randint(-15, 25)),
                               base_price=price * random.uniform(0.85, 1.2) / (1 if airline == "Aurelia Air" else 1.15), aircraft=ac)
                    db.session.add(f); create_seats(f)
    db.session.commit()
    demo = User.query.filter_by(email="user@aurelia.demo").first()
    for f in random.sample(Flight.query.all(), 40):
        cabin = random.choice(["Economy"] * 3 + ["Business"])
        ids = [s.id for s in random.sample([s for s in f.seats if s.cabin == cabin], 2)]
        create_booking(demo, f, cabin, [("Alex Morgan", "P1234567"), ("Sam Morgan", "P7654321")], ids)
    print("Seeded. Admin: admin@aurelia.demo / AdminDemo123!  User: user@aurelia.demo / UserDemo123!")


if __name__ == "__main__":
    with create_app().app_context(): seed()
