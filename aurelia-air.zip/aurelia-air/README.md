# AURELIA AIR ✈

Premium flight booking and airline management demo built with Flask, SQLAlchemy, Flask-Login, Chart.js and Lucide.

> **Simulated data.** Flights, prices and payments are demo data. No real airline inventory, no real payments.

## Features
Search (filters + sorting, round trip/one way), flight details, interactive seat map with fees, booking with simulated payment, unique booking references, cancellation with seat release, registration/login, per-user booking authorization, admin dashboard (Chart.js), flight create/edit/delete, booking status management, CSRF protection, hashed passwords.

## Run locally (macOS)
```bash
cd aurelia-air
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env     # then set a random SECRET_KEY
export $(grep -v '^#' .env | xargs)
python seed.py
flask --app "app:create_app" run
```
Open http://127.0.0.1:5000. Docker: `cp .env.example .env && docker compose up --build` then http://localhost:8000.

## Demo accounts (demo only)
| Role | Email | Password |
|---|---|---|
| Admin | admin@aurelia.demo | AdminDemo123! |
| User | user@aurelia.demo | UserDemo123! |

## Architecture
`app/models.py` (User, Airport, Aircraft, Flight, Seat, Booking, Passenger, Payment, BookingSeat) · `app/services.py` (transactional booking; a unique constraint on `BookingSeat.seat_id` prevents double booking) · `app/routes.py` (public + auth + booking) · `app/admin.py` (role-protected) · `seed.py`.

## Routes
`GET /search?origin&destination&depart&pax&cabin&max_price&max_dur&tod&airline&sort`, `GET /flight/<id>`, `GET|POST /book/<id>`, `GET /booking/<ref>`, `POST /booking/<ref>/cancel`, `/admin/*` (admin only).

## Known limitations
Not production-ready: no security review, no real payments, SQLite only, round trips are booked one leg at a time, no airport or per-seat admin management screens, **automated tests are not included yet and the app has not been run end-to-end**. Add screenshots to `docs/screenshots/`.
