import random, re, string
from sqlalchemy.exc import IntegrityError
from . import db
from .models import *


class BookingError(Exception): pass


def create_seats(flight, rows=18):
    for r in range(1, rows + 1):
        cabin, extra = ("First", 300) if r <= 2 else ("Business", 150) if r <= 6 else ("Economy", 25 if r <= 9 else 0)
        for c in "ABCDEF":
            db.session.add(Seat(flight=flight, number=f"{r}{c}", cabin=cabin, extra=extra))


def create_booking(user, flight, cabin, pax, seat_ids):
    if cabin not in CABIN_MULT: raise BookingError("Invalid cabin class.")
    if not 1 <= len(pax) <= 9 or len(set(seat_ids)) != len(pax):
        raise BookingError("Select exactly one distinct seat per passenger.")
    for n, p in pax:
        if len(n.strip()) < 2 or not re.fullmatch(r"[A-Za-z0-9]{5,12}", p):
            raise BookingError("Enter a valid name and a 5-12 character passport number for each passenger.")
    seats = Seat.query.filter(Seat.id.in_(seat_ids), Seat.flight_id == flight.id, Seat.cabin == cabin).all()
    if len(seats) != len(pax): raise BookingError("Invalid seat selection for this cabin.")
    total = sum(flight.price(cabin) + s.extra for s in seats)
    ref = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    try:
        b = Booking(ref=ref, user_id=user.id, flight_id=flight.id, cabin=cabin, total=total)
        db.session.add(b); db.session.flush()
        for (n, p), s in zip(pax, seats):
            db.session.add(BookingSeat(booking_id=b.id, seat_id=s.id))
            db.session.add(Passenger(booking_id=b.id, name=n.strip(), passport=p, seat_number=s.number))
        db.session.add(Payment(booking_id=b.id, amount=total))
        db.session.commit()
        return b
    except IntegrityError:
        db.session.rollback()
        raise BookingError("One of those seats was just taken. Please choose another.")


def cancel_booking(b):
    if b.status == "Cancelled": return
    b.status = "Cancelled"
    for bs in list(b.seats): db.session.delete(bs)
    if b.payment: b.payment.status = "Refunded"
    db.session.commit()
