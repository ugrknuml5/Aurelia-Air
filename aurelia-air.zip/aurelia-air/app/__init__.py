import os
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect

db, login, csrf = SQLAlchemy(), LoginManager(), CSRFProtect()


def create_app(cfg=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-only-change-me"),
        SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", "sqlite:///aurelia.db"),
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
    if cfg:
        app.config.update(cfg)
    db.init_app(app); login.init_app(app); csrf.init_app(app)
    login.login_view = "main.login"
    from .routes import bp
    from .admin import admin
    app.register_blueprint(bp)
    app.register_blueprint(admin, url_prefix="/admin")
    for code, msg in ((403, "You do not have access to this page."), (404, "Page not found."), (400, "Bad request.")):
        app.register_error_handler(code, lambda e, c=code, m=msg: (render_template("error.html", code=c, msg=m), c))
    with app.app_context():
        db.create_all()
    return app
