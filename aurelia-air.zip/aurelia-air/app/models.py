from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from . import db, login

CABIN_MULT = {"Economy": 1, "Business": 2.5, "First": 4}


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    name = db.Column(db.String(80), nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    bookings = db.relationship("Booking", backref="user")

    def set_password(self, p): self.password_hash = generate_password_hash(p)
    def check_password(self, p): return check_password_hash(self.password_hash, p)


@login.user_loader
def load_user(uid): return db.session.get(User, int(uid))


class Airport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(3), unique=True, nullable=False)
    city = db.Column(db.String(60), nullable=False)
    country = db.Column(db.String(60), nullable=False)


class Aircraft(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    model = db.Column(db.String(60), nullable=False)
    rows = db.Column(db.Integer, default=18)


class Flight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.String(10), nullable=False)
    airline = db.Column(db.String(60), default="Aurelia Air", index=True)
    origin_id = db.Column(db.ForeignKey("airport.id"), nullable=False, index=True)
    dest_id = db.Column(db.ForeignKey("airport.id"), nullable=False, index=True)
    depart = db.Column(db.DateTime, nullable=False, index=True)
    arrive = db.Column(db.DateTime, nullable=False)
    base_price = db.Column(db.Float, nullable=False)
    aircraft_id = db.Column(db.ForeignKey("aircraft.id"))
    origin = db.relationship("Airport", foreign_keys=[origin_id])
    destination = db.relationship("Airport", foreign_keys=[dest_id])
    aircraft = db.relationship("Aircraft")
    seats = db.relationship("Seat", backref="flight", cascade="all, delete-orphan")
    bookings = db.relationship("Booking", backref="flight")

    @property
    def duration(self): return int((self.arrive - self.depart).total_seconds() // 60)
    def price(self, cabin="Economy"): return round(self.base_price * CABIN_MULT[cabin])


class Seat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.ForeignKey("flight.id"), nullable=False, index=True)
    number = db.Column(db.String(4), nullable=False)
    cabin = db.Column(db.String(10), nullable=False)
    extra = db.Column(db.Float, default=0)
    __table_args__ = (db.UniqueConstraint("flight_id", "number"),)


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ref = db.Column(db.String(8), unique=True, nullable=False, index=True)
    user_id = db.Column(db.ForeignKey("user.id"), nullable=False, index=True)
    flight_id = db.Column(db.ForeignKey("flight.id"), nullable=False)
    cabin = db.Column(db.String(10), nullable=False)
    status = db.Column(db.String(12), default="Confirmed")
    total = db.Column(db.Float, nullable=False)
    created = db.Column(db.DateTime, default=datetime.utcnow)
    passengers = db.relationship("Passenger", backref="booking", cascade="all, delete-orphan")
    payment = db.relationship("Payment", backref="booking", uselist=False, cascade="all, delete-orphan")
    seats = db.relationship("BookingSeat", backref="booking", cascade="all, delete-orphan")


class Passenger(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.ForeignKey("booking.id"), nullable=False)
    name = db.Column(db.String(80), nullable=False)
    passport = db.Column(db.String(12), nullable=False)
    seat_number = db.Column(db.String(4))


class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.ForeignKey("booking.id"), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(10), default="Paid")  # simulated
    created = db.Column(db.DateTime, default=datetime.utcnow)


class BookingSeat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.ForeignKey("booking.id"), nullable=False)
    seat_id = db.Column(db.ForeignKey("seat.id"), nullable=False, unique=True)  # no double booking
    seat = db.relationship("Seat")
