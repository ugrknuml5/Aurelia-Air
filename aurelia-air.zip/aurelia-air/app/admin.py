from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import current_user
from sqlalchemy import func
from . import db
from .models import *
from .services import create_seats, cancel_booking

admin = Blueprint("admin", __name__)


@admin.before_request
def guard():
    if not current_user.is_authenticated: return redirect(url_for("main.login", next=request.path))
    if not current_user.is_admin: abort(403)


@admin.route("/")
def dashboard():
    status = dict(db.session.query(Booking.status, func.count()).group_by(Booking.status).all())
    top = {}
    for b in Booking.query.filter_by(status="Confirmed").all():
        k = f"{b.flight.origin.code}-{b.flight.destination.code}"; top[k] = top.get(k, 0) + b.total
    top = sorted(top.items(), key=lambda x: -x[1])[:6]
    revenue = sum(p.amount for p in Payment.query.filter_by(status="Paid"))
    return render_template("admin.html", users=User.query.count(), bookings=Booking.query.count(), revenue=revenue,
        status=status, top=top, recent=Booking.query.order_by(Booking.created.desc()).limit(8).all())


def _fill(f):
    r = request.form
    try:
        f.number, f.airline = r["number"].strip()[:10], r["airline"].strip()[:60]
        f.origin_id, f.dest_id = int(r["origin"]), int(r["dest"])
        f.depart, f.arrive = datetime.fromisoformat(r["depart"]), datetime.fromisoformat(r["arrive"])
        f.base_price = float(r["price"])
    except (KeyError, ValueError): return "Please complete every field with valid values."
    if f.origin_id == f.dest_id or f.arrive <= f.depart or f.base_price <= 0 or not f.number:
        return "Airports must differ, arrival must follow departure and price must be positive."


@admin.route("/flights")
def flights():
    return render_template("admin_flights.html", items=Flight.query.order_by(Flight.depart).limit(200).all())


@admin.route("/flights/new", methods=["GET", "POST"])
@admin.route("/flights/<int:fid>", methods=["GET", "POST"])
def flight_form(fid=None):
    f = db.get_or_404(Flight, fid) if fid else Flight()
    if request.method == "POST":
        err = _fill(f)
        if err: flash(err, "error")
        else:
            if not fid:
                f.aircraft = Aircraft.query.first() or Aircraft(model="Boeing 787-9")
                db.session.add(f); create_seats(f)
            db.session.commit(); flash("Flight saved.", "ok"); return redirect(url_for("admin.flights"))
    return render_template("admin_flight_form.html", f=f, airports=Airport.query.order_by(Airport.city).all())


@admin.route("/flights/<int:fid>/delete", methods=["POST"])
def flight_delete(fid):
    f = db.get_or_404(Flight, fid)
    if f.bookings: flash("Cannot delete a flight that has bookings. Cancel them first.", "error")
    else: db.session.delete(f); db.session.commit(); flash("Flight deleted.", "ok")
    return redirect(url_for("admin.flights"))


@admin.route("/bookings")
def bookings():
    return render_template("admin_bookings.html", items=Booking.query.order_by(Booking.created.desc()).limit(200).all())


@admin.route("/bookings/<int:bid>/status", methods=["POST"])
def booking_status(bid):
    b, s = db.get_or_404(Booking, bid), request.form.get("status")
    if s == "Cancelled": cancel_booking(b)
    elif s in ("Confirmed", "Completed") and b.status != "Cancelled": b.status = s; db.session.commit()
    else: flash("Cancelled bookings cannot be reactivated.", "error")
    return redirect(url_for("admin.bookings"))
