import re
from datetime import date, datetime, timedelta, time
from urllib.parse import urlparse
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_user, logout_user, login_required, current_user
from . import db
from .models import *
from .services import BookingError, create_booking, cancel_booking

bp = Blueprint("main", __name__)
TOD = {"morning": (0, 12), "afternoon": (12, 18), "evening": (18, 24)}


def _int(v, d, lo, hi):
    try: return max(lo, min(hi, int(v)))
    except (TypeError, ValueError): return d


def run_search(a, o, d, day, cabin):
    q = Flight.query.filter(Flight.origin.has(code=o), Flight.destination.has(code=d),
                            Flight.depart >= datetime.combine(day, time.min),
                            Flight.depart < datetime.combine(day, time.min) + timedelta(days=1))
    if a.get("airline"): q = q.filter(Flight.airline == a["airline"])
    res = q.all()
    if a.get("max_price"): res = [f for f in res if f.price(cabin) <= _int(a["max_price"], 10**6, 0, 10**6)]
    if a.get("tod") in TOD: lo, hi = TOD[a["tod"]]; res = [f for f in res if lo <= f.depart.hour < hi]
    if a.get("max_dur"): res = [f for f in res if f.duration <= _int(a["max_dur"], 10**5, 0, 10**5) * 60]
    key = {"cheapest": lambda f: f.price(cabin), "fastest": lambda f: f.duration}.get(
        a.get("sort"), lambda f: f.price(cabin) + f.duration * 0.5)
    return sorted(res, key=key)


@bp.app_template_filter("dur")
def dur(m): return f"{m // 60}h {m % 60:02d}m"


@bp.route("/")
def index():
    fl = Flight.query.filter(Flight.depart >= datetime.utcnow()).order_by(Flight.base_price).limit(80).all()
    seen, popular = set(), []
    for f in fl:
        if (f.origin_id, f.dest_id) not in seen and len(popular) < 6:
            seen.add((f.origin_id, f.dest_id)); popular.append(f)
    return render_template("index.html", airports=Airport.query.order_by(Airport.city).all(),
                           cabins=CABIN_MULT, today=date.today(), popular=popular)


@bp.route("/search")
def search():
    a = request.args
    try: day = date.fromisoformat(a.get("depart", ""))
    except ValueError:
        flash("Please choose a valid departure date.", "error"); return redirect(url_for("main.index"))
    cabin = a.get("cabin", "Economy")
    if cabin not in CABIN_MULT or not a.get("origin") or a.get("origin") == a.get("destination"):
        flash("Choose different departure and arrival airports.", "error"); return redirect(url_for("main.index"))
    pax = _int(a.get("pax"), 1, 1, 9)
    out = run_search(a, a["origin"], a.get("destination"), day, cabin)
    back = None
    if a.get("trip") == "round" and a.get("return_date"):
        try: back = run_search(a, a["destination"], a["origin"], date.fromisoformat(a["return_date"]), cabin)
        except ValueError: flash("Invalid return date.", "error")
    airlines = [r[0] for r in db.session.query(Flight.airline).distinct()]
    return render_template("results.html", out=out, back=back, cabin=cabin, pax=pax, airlines=airlines, a=a)


@bp.route("/flight/<int:fid>")
def flight(fid):
    f = db.get_or_404(Flight, fid)
    cabin = request.args.get("cabin", "Economy")
    if cabin not in CABIN_MULT: abort(400)
    return render_template("flight.html", f=f, cabin=cabin, pax=_int(request.args.get("pax"), 1, 1, 9))


@bp.route("/book/<int:fid>", methods=["GET", "POST"])
@login_required
def book(fid):
    f = db.get_or_404(Flight, fid)
    cabin = request.values.get("cabin", "Economy")
    if cabin not in CABIN_MULT: abort(400)
    pax = _int(request.values.get("pax"), 1, 1, 9)
    if request.method == "POST":
        names, pp = request.form.getlist("name"), request.form.getlist("passport")
        try:
            if len(names) != pax or len(pp) != pax: raise BookingError("Complete all passenger details.")
            b = create_booking(current_user, f, cabin, list(zip(names, pp)), request.form.getlist("seat", type=int))
            flash("Simulated payment accepted. Your booking is confirmed!", "ok")
            return redirect(url_for("main.booking", ref=b.ref))
        except BookingError as e:
            flash(str(e), "error")
    taken = {r[0] for r in db.session.query(BookingSeat.seat_id).join(Seat).filter(Seat.flight_id == fid)}
    rows = {}
    for s in sorted(f.seats, key=lambda s: (int(s.number[:-1]), s.number[-1])): rows.setdefault(int(s.number[:-1]), []).append(s)
    return render_template("book.html", f=f, cabin=cabin, pax=pax, rows=rows, taken=taken)


def _own(ref):
    b = Booking.query.filter_by(ref=ref).first_or_404()
    if b.user_id != current_user.id and not current_user.is_admin: abort(403)
    return b


@bp.route("/booking/<ref>")
@login_required
def booking(ref): return render_template("booking.html", b=_own(ref))


@bp.route("/booking/<ref>/cancel", methods=["POST"])
@login_required
def cancel(ref):
    cancel_booking(_own(ref)); flash("Booking cancelled. Simulated refund issued.", "ok")
    return redirect(url_for("main.my_bookings"))


@bp.route("/my-bookings")
@login_required
def my_bookings():
    return render_template("bookings.html", items=Booking.query.filter_by(user_id=current_user.id).order_by(Booking.created.desc()).all())


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        n, e, p = request.form.get("name", "").strip(), request.form.get("email", "").strip().lower(), request.form.get("password", "")
        if len(n) < 2 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", e) or len(p) < 8:
            flash("Enter your name, a valid email and a password of at least 8 characters.", "error")
        elif User.query.filter_by(email=e).first(): flash("That email is already registered.", "error")
        else:
            u = User(name=n, email=e); u.set_password(p); db.session.add(u); db.session.commit()
            login_user(u); return redirect(url_for("main.index"))
    return render_template("auth.html", mode="register")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(email=request.form.get("email", "").strip().lower()).first()
        if u and u.check_password(request.form.get("password", "")):
            login_user(u); nxt = request.args.get("next", "")
            ok = nxt.startswith("/") and not nxt.startswith("//") and not urlparse(nxt).netloc
            return redirect(nxt if ok else url_for("main.index"))
        flash("Invalid email or password.", "error")
    return render_template("auth.html", mode="login")


@bp.route("/logout", methods=["POST"])
@login_required
def logout(): logout_user(); return redirect(url_for("main.index"))
